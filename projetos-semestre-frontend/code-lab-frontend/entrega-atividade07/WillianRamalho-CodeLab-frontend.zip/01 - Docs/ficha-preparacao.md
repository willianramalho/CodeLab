# Ficha de Preparação — CodeLab

| Dado | Seu valor |
|---|---|
| Nome do projeto | CodeLab – Plataforma de Desafios de Programação |
| Entidade principal | Desafio (`Challenge`) |
| Porta da API (back-end) | 3000 |
| Porta do front-end (Vue/Vite) | 5173 |
| Nome do campo de busca da entidade principal (plural, camelCase) | `challenges` |
| Nome do banco de dados MySQL do seu projeto | `codelab_db` |
| Nome do campo de contagem de itens publicados (plural, camelCase) | `challengesCount` |
| Cor de marca do seu projeto (hex) | `#198754` (verde) |
| Nome do model da sua entidade principal (singular, PascalCase) | `Challenge` |
| Nome da tabela (plural, snake_case) | `challenges` |
| Grupo (A ou B, conforme acima) | **B** |
| Nome do campo do arquivo principal | `sourceCode` |
| Nome do campo da capa — só se Grupo A | — (não se aplica: Grupo B) |
| Nome da coluna de contagem no `User` que será incrementada hoje | `challengesCount` |

> Observação: esta ficha foi recriada com base nas configurações já presentes no
> projeto (`.env` do back-end e do front-end) e na Lista de Projetos, pois a versão
> original criada na Atividade da Aula 01 não foi encontrada na pasta do projeto.
> Confirme os valores acima e ajuste se algo estiver diferente do que você registrou
> na Aula 01.
>
> As 6 linhas finais foram preenchidas na Atividade 07 (Seção 2 do enunciado); ver o
> detalhamento e as observações sobre Grupo B e a divergência `DESCRIPTION_MAX` em
> `atividade07/ficha-preparacao.md`.
