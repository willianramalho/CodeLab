var express = require('express');
var logger = require('morgan');
var cors = require('cors');
var path = require('path');
require('dotenv').config();

var indexRouter = require('./routes/index');
var searchRoutes = require('./modules/search/searchRoutes');
var userRoutes = require('./modules/user/userRoutes');
var challengeRoutes = require('./modules/challenge/challengeRoutes');
var errorHandler = require('./middlewares/errorHandler');

var app = express();

// --- Middlewares globais ---
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// CORS: permite que o front-end Vue (rodando em outra origem/porta) consuma a API.
app.use(cors({
    origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
    credentials: true
}));

// Pasta de uploads servida publicamente (ex: /uploads/profiles/<arquivo>).
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

// --- Montagem das rotas da API ---
// Todas as rotas ficam sob o prefixo /api (ex: /api/register, /api/challenges).
app.use('/api', indexRouter);
app.use('/api', searchRoutes);
app.use('/api', userRoutes);
app.use('/api', challengeRoutes);

// Captura qualquer rota não tratada pelos routers acima
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Rota não encontrada.',
        errors: []
    });
});

// Middleware de erro centralizado — precisa ser o último app.use() do arquivo,
// pois só é alcançado via next(err), nunca pela ordem normal de execução.
app.use(errorHandler);

const sequelize = require('./config/database');
// Precisa ser carregado ANTES do sync(), senão a tabela challenges nasce
// sem a foreign key para users (ver config/associations.js).
require('./config/associations');
sequelize.sync({ alter: true })
    .then(() => console.log('Banco de dados sincronizado!'))
    .catch(err => console.error('Erro ao sincronizar banco:', err));

module.exports = app;