import { storeToRefs } from 'pinia'
import { useAuthStore } from '../stores/auth'

/**
 * Fachada em torno da store de autenticação (Pinia). Não duplica lógica:
 * apenas expõe o estado (via storeToRefs, para preservar reatividade ao
 * desestruturar) e as actions já existentes em `useAuthStore`.
 */
export function useAuth() {
  const authStore = useAuthStore()
  const { user, isAuthenticated, isAdmin } = storeToRefs(authStore)

  return {
    user,
    isAuthenticated,
    isAdmin,
    login: authStore.login,
    logout: authStore.logout,
  }
}
